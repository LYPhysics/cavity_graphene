close all
plot(0:1:Lm,energy(:,1:2),'LineWidth',2);
xticks([0 Lm/3 2*Lm/3 Lm]);
xticklabels({'\Gamma','K','K''','\Gamma'});
set(gca,'FontSize',30,'Fontname', 'Times New Roman');
% 
figure;
plot(0:1:Lm,Tenergy(:,1:2),'LineWidth',2);
xticks([0 Lm/3 2*Lm/3 Lm]);
xticklabels({'\Gamma','K','K''','\Gamma'});
set(gca,'FontSize',30,'Fontname', 'Times New Roman');

figure;
plot(0:1:Lm,Venergy(:,1:2),'LineWidth',2);
xticks([0 Lm/3 2*Lm/3 Lm]);
xticklabels({'\Gamma','K','K''','\Gamma'});
set(gca,'FontSize',30,'Fontname', 'Times New Roman');

% figure;
% plot(0:1:Lm,-2*imag(Qxy(:,1)),'LineWidth',2);
% xticks([0 Lm/3 2*Lm/3 Lm]);
% xticklabels({'\Gamma','K','K''','\Gamma'});
% set(gca,'FontSize',30,'Fontname', 'Times New Roman');

% figure;
% plot(0:1:Lm,-2*imag(Qxy1(:,1)),'LineWidth',2);
% xticks([0 Lm/3 2*Lm/3 Lm]);
% xticklabels({'\Gamma','K','K''','\Gamma'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% figure;
% plot(0:1:Lm,-2*imag(Qxy2(:,1)),'LineWidth',2);
% xticks([0 Lm/3 2*Lm/3 Lm]);
% xticklabels({'\Gamma','K','K''','\Gamma'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% figure;
% plot(0:1:Lm,-2*imag(Qxy3(:,1)),'LineWidth',2);
% xticks([0 Lm/3 2*Lm/3 Lm]);
% xticklabels({'\Gamma','K','K''','\Gamma'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% 
% figure;
% plot(0:1:Lm,Tenergy(:,1)*ratio/wc,'LineWidth',2);
% xticks([0 Lm/3 2*Lm/3 Lm]);
% xticklabels({'\Gamma','K','K''','\Gamma'});
% set(gca,'FontSize',30,'Fontname', 'Times New Roman');