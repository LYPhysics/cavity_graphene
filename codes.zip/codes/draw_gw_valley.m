close all
% % theta
% figure;
% plot(0:pi/100:pi/2,RvalleyK(1:end,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',35,'Fontname', 'Times New Roman');
% 
% legend('g/\omega_c=0.5','g/\omega_c=0.75','g/\omega_c=1');
% 


% figure;
% plot(0:0.01:2,gap(:,2)./Width(:,1),'LineWidth',2);
% %ylim([-0.3 1]);
% %yticks([ -0.2 0 0.15 0.3]);
% xticks([0 0.453 1.301 2]);
% xline(0.453,'--');hold on;
% xline(1.301,'--');
% set(gca,'FontSize',35,'Fontname', 'Times New Roman');
% axes('Position',[.44 .4 .3 .3])
% box on
% plot(0:0.01:2,gap(:,2),'LineWidth',2);
% xticks([0 2]);
% xline(0.453,'--');hold on;
% xline(1.301,'--');
% set(gca,'FontSize',30,'Fontname', 'Times New Roman');
% 
% figure;
% plot(0:0.01:2,gap(:,2)/wc,'LineWidth',2);
% %ylim([-0.3 1]);
% %yticks([ -0.2 0 0.15 0.3]);
% xticks([0 0.453 1.301 2]);
% xline(0.453,'--');hold on;
% xline(1.301,'--');
% set(gca,'FontSize',35,'Fontname', 'Times New Roman');


% % valley split
figure;
plot(0:0.01:2,abs(RvalleyK(1:end,1)),'LineWidth',2);
xticks([0 0.453 1.301 2]);
xline(0.453,'--');hold on;
xline(1.301,'--');
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
axes('Position',[.58 .2 .3 .3])
box on
plot(0:0.01:2,-DE(1:end,1),'LineWidth',2);
%ylim([-0.2 1.3]);
yticks([0 0.1 0.2]);
xticks([0  2]);
xline(0.453,'--');hold on;
xline(1.301,'--');
set(gca,'FontSize',25,'Fontname', 'Times New Roman');

figure;
plot(0:0.01:2,[photon1(1:end,1),photon2(1:end,1)],'LineWidth',2);
xticks([0 0.453 1.301 2]);
xline(0.453,'--');hold on;
xline(1.301,'--');
ylim([-0.08 0.08]);
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
legend('$K$','$K''$','Interpreter','latex','Position',[.4 .4 .1 .1]);

figure;
plot(0.01:0.01:2,[dT(2:end,1),dV(2:end,1)],'LineWidth',2);
xticks([0 0.453 1.301 2]);
xline(0.453,'--');hold on;
xline(1.301,'--');
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
legend('$\frac{T_K-T_{K''}}{E_K-E_{K''}}$','$\frac{V_K-V_{K''}}{E_K-E_{K''}}$','Interpreter','latex','Position',[.72 .46 .1 .1]);


% figure;
% plot(0.01:0.01:2,[dT(2:end,1),dV(2:end,1)],'LineWidth',2);
% xticks([0.01 0.453 1.301 2]);
% %ylim([-0.3 1.3]);
% %yticks([-0.1 0 0.5 1.1]);
% xline(0.453,'--');hold on;
% xline(1.301,'--');
% set(gca,'FontSize',32,'Fontname', 'Times New Roman');
% legend('$\frac{T_K-T_{K''}}{E_K-E_{K''}}$','$\frac{V_K-V_{K''}}{E_K-E_{K''}}$','Interpreter','latex');
% 

% hold on
% plot(0:pi/100:pi/2,energyTheta(2,:),'LineWidth',2);
% legend('K','K''')
% 
% figure;
% plot(0:pi/100:pi/2,energyTheta(1,:)-energyTheta(2,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% 
