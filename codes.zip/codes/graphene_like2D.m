clear all
close all

n1=10;
n2=10;
N1=2*n1+1;
N2=2*n2+1; 

a1=sqrt(3)*[cos(pi/6),sin(pi/6)];
a2=sqrt(3)*[cos(5*pi/6),sin(5*pi/6)];
b1=4*pi*[cos(pi/3),sin(pi/3)]/3;
b2=4*pi*[cos(2*pi/3),sin(2*pi/3)]/3;
b3=b1-b2;

Lbz1=100;
Lbz2=30;
DL=20;


mass=1.5;
V0=1.5;
Delta=1;
wc=2;

gw=0.1;
meff=mass*(1+gw^2); 
xi=gw/(1+gw^2)/sqrt(mass*wc);
ratio=gw^2/(1+gw^2);



j=0;
nn=0;

    for h1=-n1:1:n1
    for h2=-n2:1:n2

        j=j+1;
        vK=b1*h1+b2*h2;
        tK=[vK(1,2),-vK(1,1)];
        Kxy(j,1:2)=vK;

        l1(j,1)=exp(1i*tK*b1'*xi^2/2);
        l2(j,1)=exp(1i*tK*b2'*xi^2/2);
        l3(j,1)=exp(1i*tK*b3'*xi^2/2);

        if abs(vK(1,2))<=((4*pi*n1*sqrt(3)/6)+0.001)
            nn=nn+1;
            Kpoints(nn,1)=j;
        end
       

    end
    end
L1=sparse(diag(l1));
L2=sparse(diag(l2));
L3=sparse(diag(l3));

scatter(Kxy(Kpoints,1),Kxy(Kpoints,2),40,'red','filled'); 
axis equal



o1(1:(N1-1))=1;
o2(1:(N2-1))=1;

I1=sparse(eye(N1));
I2=sparse(eye(N2));
I=kron(I1,I2);

%k to k+b1 and k-b1
up1=sparse(diag(o1,-1));
down1=up1';
Ub1=kron(up1,I2);
Db1=kron(down1,I2);

%k to k+b2 and k-b2
up2=sparse(diag(o2,-1));
down2=up2';
Ub2=kron(I1,up2);
Db2=kron(I1,down2);

%k to k+b3 and k-b3, b3=b1-b2
Ub3=Ub1*Db2;
Db3=Db1*Ub2;



kk=0;
kkk=0;
% %%2D kv
for h1=0:1:(Lbz1-1)
    %for h1=(Lbz1/3-Lbz1/DL):1:(Lbz1/3+Lbz1/DL)
    for h2=0:1:(Lbz2-1)

            kko=b1*(h1)/(Lbz1)+b2*(h2)/(Lbz2);
            kk=kk+1;
            ko(kk,1:2)=kko;


           % if h1~=Lbz&&h2~=Lbz
           %     kkk=kkk+1;
           %      kkon(kkk,1)=kk;
           %  end

    end
end
%1D kv, Lm=200
% Lm=200;

%for h=0:1:Lm
% 
%     kk=kk+1;
%     ko(kk,1:2)=(b1+b2)*(1-h/Lm);
% 
%end
%band=100;

xig=xi^2*4*pi^2/9;

for jj=1:kk
    
    kox=ko(jj,1);
    koy=ko(jj,2);
    
    v1=(V0+Delta/9*exp(-1i*2*pi/3))*exp(-xig+1i*xi^2/2*([koy,-kox]*b1'));
    v2=(V0+Delta/9*exp(1i*2*pi/3))*exp(-xig+1i*xi^2/2*([koy,-kox]*b2'));
    v3=(V0+Delta/9*exp(-1i*4*pi/3))*exp(-xig+1i*xi^2/2*([koy,-kox]*b3'));

    Ek(:,1)=sum((Kxy(:,1:2)+ko(jj,1:2)).^2,2)/(2*meff);
    Kinetic=sparse(diag(Ek));

    V1=v1*Ub1*L1;
    V2=v2*Ub2*L2;
    V3=v3*Ub3*L3;
    V=V1+V1'+V2+V2'+V3+V3';
    Hfull=Kinetic+V;

    % j1x=-1i*xi^2*b1(1,2)*V1/2;
    % j1y=1i*xi^2*b1(1,1)*V1/2;
    % j2x=-1i*xi^2*b2(1,2)*V2/2;
    % j2y=1i*xi^2*b2(1,1)*V2/2;
    % j3x=-1i*xi^2*b3(1,2)*V3/2;
    % j3y=1i*xi^2*b3(1,1)*V3/2;
    % JJx=diag(Kxy(:,1)+ko(jj,1))/meff+j1x+j1x'+j2x+j2x'+j3x+j3x';
    % JJy=diag(Kxy(:,2)+ko(jj,2))/meff+j1y+j1y'+j2y+j2y'+j3y+j3y';
    % Jx=JJx(Kpoints,Kpoints);
    % Jy=JJy(Kpoints,Kpoints);

    H=Hfull(Kpoints,Kpoints);

    
    [Psi,W]=eig(full(H));
    w=diag(W);
    energy(jj,:)=w'+wc*(1+gw^2)/2;

    Psik(:,jj)=Psi(:,1);
    % 
    % M=diag(1./(w(2:end)-w(1)))*(Psi(:,2:end)');
    % qx=M*Jx*Psi(:,1);
    % qy=M*Jy*Psi(:,1);
    % Qxy(jj,1)=qx'*qy;
    % Qxx(jj,1)=qx'*qx;
    % Qyy(jj,1)=qy'*qy;
    % Tenergy(jj,1)=(abs(Psi(:,1)).^2)'*diag(Kinetic(Kpoints,Kpoints));
    % Tenergy(jj,2)=(abs(Psi(:,2)).^2)'*diag(Kinetic(Kpoints,Kpoints));
    % Venergy(jj,1)=energy(jj,1)-Tenergy(jj,1);
    % Venergy(jj,2)=energy(jj,2)-Tenergy(jj,2);

end

% volg=sqrt(Qxx.*Qyy-real(Qxy).^2);
% Np=sum(Tenergy(:,1)*ratio/wc)/kk;
% Chern=sum(-2*imag(Qxy(:,1)))*(4*pi)/(kk*3*sqrt(3));
% %draw_psi(energy(:,1),ko,2);
% draw_psi(-2*imag(Qxy),ko,1);
% %draw_psi(Tenergy(:,1),ko,2);
% draw_psi(Tenergy(:,1)*ratio/wc,ko,2);
% 
% draw_psi(Qxx(:,1)+Qyy(:,1),ko,2);
% draw_psi(volg(:,1),ko,2);