hh=0;


%for h1=(Lbz1/3-Lbz1/DL):1:(Lbz1/3+Lbz1/DL)
for hh=0:1:(Lbz1-1)
    hh=hh+1;
    WL(hh,1)=1;

    for h2=0:1:(Lbz2-1)
    k=(hh-1)*Lbz2+h2+1;

    if h2~=(Lbz2-1)
    WL(hh,1)=WL(hh,1)*(Psik(:,k+1))'*Psik(:,k);
    end

    if h2==(Lbz2-1)
    WL(hh,1)=WL(hh,1)*(Psik(:,(hh-1)*Lbz2+1))'*Psik(:,k);
    end

    end

end

close all
figure;
plot((0:1:(Lbz1-1))*2*pi./Lbz1,angle(WL)/(2*pi),'.','MarkerSize',10)
xticks([0 pi 2*pi*(1-1/Lbz1)]);
xticklabels({'0','\pi','2\pi'});
set(gca,'FontSize',30,'Fontname', 'Times New Roman');

% plot(((Lbz1/3-Lbz1/DL):1:(Lbz1/3+Lbz1/DL))*2*pi./Lbz1,angle(WL)/(2*pi),'.','MarkerSize',10)
% set(gca,'FontSize',30,'Fontname', 'Times New Roman');
