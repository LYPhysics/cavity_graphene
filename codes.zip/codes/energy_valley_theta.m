clear all
close all

n1=10;
n2=10;
N1=2*n1+1;
N2=2*n2+1; 

a1=sqrt(3)*[cos(pi/6),sin(pi/6)];
a2=sqrt(3)*[cos(5*pi/6),sin(5*pi/6)];
b1=4*pi*[cos(pi/3),sin(pi/3)]/3;
b2=4*pi*[cos(2*pi/3),sin(2*pi/3)]/3;
b3=b1-b2;
V0=1.5;
M=1.5;
Delta=0.6;
wc=2;
gwk=0;
for gw=[0.5,0.75,1]

thetak=0;

for theta=0:pi/100:pi/2

thetak=thetak+1;

cx=sqrt(2)*cos(pi/4-theta);
cy=sqrt(2)*sin(pi/4-theta);
cv=[cx,cy];

gammax=sqrt(1+cx^2*gw^2);
gammay=sqrt(1+cy^2*gw^2);
C2=[cx^2*gammay/gammax,cy^2*gammax/gammay];

mx=M*(1+cx^2*gw^2);
my=M*(1+cy^2*gw^2);
Omega=wc*gammax*gammay;

lx=cx*gw/(1+cx^2*gw^2)/sqrt(M*wc);
ly=cy*gw/(1+cy^2*gw^2)/sqrt(M*wc);

zeta=gw/(sqrt(M*wc)*gammax*gammay);

ratio=gw^2/(1+gw^2);

Zeta2=zeta^2*cos(2*theta);

j=0;
nn=0;

    for h1=-n1:1:n1
    for h2=-n2:1:n2

        j=j+1;
        vK=b1*h1+b2*h2;
        tK=[vK(1,2),-vK(1,1)];
        Kxy(j,1:2)=vK;

        l1(j,1)=exp(1i*tK*b1'*Zeta2/2);
        l2(j,1)=exp(1i*tK*b2'*Zeta2/2);
        l3(j,1)=exp(1i*tK*b3'*Zeta2/2);

        if abs(vK(1,2))<=((4*pi*n1*sqrt(3)/6)+0.001)
            nn=nn+1;
            Kpoints(nn,1)=j;
        end
       

    end
    end
L1=sparse(diag(l1));
L2=sparse(diag(l2));
L3=sparse(diag(l3));


v1(1:(N1-1))=1;
v2(1:(N2-1))=1;

I1=sparse(eye(N1));
I2=sparse(eye(N2));
I=kron(I1,I2);

%k to k+b1 and k-b1
up1=sparse(diag(v1,-1));
down1=up1';
Ub1=kron(up1,I2);
Db1=kron(down1,I2);

%k to k+b2 and k-b2
up2=sparse(diag(v2,-1));
down2=up2';
Ub2=kron(I1,up2);
Db2=kron(I1,down2);

%k to k+b3 and k-b3, b3=b1-b2
Ub3=Ub1*Db2;
Db3=Db1*Ub2;


kk=0;
%%1D kv, Lm=200
Lm=200;
for h=[Lm/3,2*Lm/3,Lm]

    kk=kk+1;
    ko(kk,1:2)=(b1+b2)*(1-h/Lm);

end


for jj=1:kk
    
    kox=ko(jj,1);
    koy=ko(jj,2);
    
    v1=(V0+Delta/9*exp(-1i*2*pi/3))*exp(-b1.^2*C2'*zeta^2/4+1i*Zeta2/2*([koy,-kox]*b1'));
    v2=(V0+Delta/9*exp(1i*2*pi/3))*exp(-b2.^2*C2'*zeta^2/4+1i*Zeta2/2*([koy,-kox]*b2'));
    v3=(V0+Delta/9*exp(-1i*4*pi/3))*exp(-b3.^2*C2'*zeta^2/4+1i*Zeta2/2*([koy,-kox]*b3'));

    Ek(:,1)=(Kxy(:,1)+ko(jj,1)).^2/(2*mx)+(Kxy(:,2)+ko(jj,2)).^2/(2*my); 
    Kinetic=sparse(diag(Ek));

    V1=v1*Ub1*L1;
    % j1x=-1i*Zeta2*b1(1,2)*V1/2;
    % j1y=1i*Zeta2*b1(1,1)*V1/2;

    V2=v2*Ub2*L2;
    % j2x=-1i*Zeta2*b2(1,2)*V2/2;
    % j2y=1i*Zeta2*b2(1,1)*V2/2;

    V3=v3*Ub3*L3;
    % j3x=-1i*Zeta2*b3(1,2)*V3/2;
    % j3y=1i*Zeta2*b3(1,1)*V3/2;

    V=V1+V1'+V2+V2'+V3+V3';

    Hfull=Kinetic+V;
    % 
    % JJx=diag(Kxy(:,1)+ko(jj,1))/mx+j1x+j1x'+j2x+j2x'+j3x+j3x';
    % JJy=diag(Kxy(:,2)+ko(jj,2))/my+j1y+j1y'+j2y+j2y'+j3y+j3y';
    % 
    % Jx=JJx(Kpoints,Kpoints);
    % Jy=JJy(Kpoints,Kpoints);
    

    H=Hfull(Kpoints,Kpoints);


    
    [Psi,W]=eig(full(H)); 
    

    w=diag(W);
    energy(jj,:)=w'+Omega/2;

    energyTheta(jj,thetak)=energy(jj,1);
    % 
    % MM=diag(1./(w(2:end)-w(1)))*(Psi(:,2:end)');
    % qx=MM*Jx*Psi(:,1);
    % qy=MM*Jy*Psi(:,1);
    % Qxy(jj,1)=qx'*qy;
    % Qxx(jj,1)=qx'*qx;
    % Qyy(jj,1)=qy'*qy;
    % Tenergy(jj,1)=(abs(Psi(:,1)).^2)'*diag(Kinetic(Kpoints,Kpoints));
    % Tenergy(jj,2)=(abs(Psi(:,2)).^2)'*diag(Kinetic(Kpoints,Kpoints));
    % Venergy(jj,1)=energy(jj,1)-Tenergy(jj,1);
    % Venergy(jj,2)=energy(jj,2)-Tenergy(jj,2);


end

end
gwk=gwk+1;
DeltaK(gwk,:)=energyTheta(1,:)-energyTheta(2,:);
RvalleyK(gwk,:)=(energyTheta(1,:)-energyTheta(2,:))./abs(max(energyTheta(1:2,:),[],1)-energyTheta(3,:));
end

% close all
% plot(0:pi/100:pi/2,energyTheta(1,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% 
% hold on
% plot(0:pi/100:pi/2,energyTheta(2,:),'LineWidth',2);
% legend('K','K''')
% 
% figure;
% plot(0:pi/100:pi/2,energyTheta(1,:)-energyTheta(2,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% 
% 