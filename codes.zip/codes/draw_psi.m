function draw_psi(psi,xy,Ctype)
figure
if Ctype==1
scatter(xy(:,1),xy(:,2),20,psi(1:end,1),'filled'); 
%colorbar('east')
colorbar
axis equal
axis off
xlabel('x')
ylabel('y')
set(gca,'FontSize',25,'Fontname', 'Times New Roman');
map = mycolormap('D1',1000);colormap(map);clim([-max(abs(psi(1:end,1))) max(abs(psi(1:end,1)))]);
hold on
k = boundary(xy(:,1),xy(:,2));
plot(xy(k,1),xy(k,2),'color','black');
end

if Ctype==2
scatter(xy(:,1),xy(:,2),20,psi(1:end,1),'filled'); 
%colorbar('east')
colorbar
axis equal
axis off
xlabel('x')
ylabel('y')
set(gca,'FontSize',25,'Fontname', 'Times New Roman');
map = mycolormap('L17',1000);colormap(map);
%clim([min(psi(1:end,1)) max(psi(1:end,1))]);0.3489
clim([0 max(psi(1:end,1))]);
%clim([0 0.35]);
hold on
k = boundary(xy(:,1),xy(:,2));
plot(xy(k,1),xy(k,2),'color','black');
end



% subplot(2,2,1);
% scatter(xy(:,1),xy(:,2),10,real(psi(1:2:end,1)),'filled'); 
% colorbar;
% axis equal
% axis off
% xlabel('x')
% ylabel('y')
% title(['Re\{\Psi_{j\downarrow}^e\}, j=',num2str(j)],'FontSize',15);
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% map = mycolormap('D1',1000);colormap(map);
% 
% subplot(2,2,2);
% scatter(xy(:,1),xy(:,2),10,imag(psi(1:2:end,1)),'filled'); 
% colorbar;
% axis equal
% axis off
% xlabel('x')
% ylabel('y')
% title(['Im\{\Psi_{j\downarrow}^e\}, j=',num2str(j)],'FontSize',15);
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% map = mycolormap('D1',1000);colormap(map);
% 
% subplot(2,2,3);
% scatter(xy(:,1),xy(:,2),10,real(psi(2:2:end,1)),'filled'); 
% colorbar;
% axis equal
% axis off
% xlabel('x')
% ylabel('y')
% title(['Re\{\Psi_{j\downarrow}^h\}, j=',num2str(j)],'FontSize',15);
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% map = mycolormap('D1',1000);colormap(map);
% 
% subplot(2,2,4);
% scatter(xy(:,1),xy(:,2),10,imag(psi(2:2:end,1)),'filled'); 
% colorbar;
% axis equal
% axis off
% xlabel('x')
% ylabel('y')
% title(['Im\{\Psi_{j\downarrow}^h\}, j=',num2str(j)],'FontSize',15);
% set(gca,'FontSize',20,'Fontname', 'Times New Roman');
% map = mycolormap('D1',1000);colormap(map);
% 
