plot(0:0.01:2,(energy(:,:)),'LineWidth',2);
xticks([0 0.5 1 1.5 2]);
set(gca,'FontSize',35,'Fontname', 'Times New Roman');

% plot(0:pi/400:pi/4,(energy(:,:)),'LineWidth',2);
% xticks([0 pi/8 pi/4 ]);
% xticklabels({'0','\pi/8','\pi/4'});
% set(gca,'FontSize',35,'Fontname', 'Times New Roman');