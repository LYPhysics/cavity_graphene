clear all
close all
sz=sparse([1,0;0,-1]);
sx=sparse([0,1;1,0]);
sy=sparse([0,-1i;1i,0]);
a1=sqrt(3)*[cos(pi/6),sin(pi/6)];
a2=sqrt(3)*[cos(5*pi/6),sin(5*pi/6)];
da=(a1-a2)/6;

b1=4*pi/3*[cos(pi/3),sin(pi/3)];
b2=4*pi/3*[cos(2*pi/3),sin(2*pi/3)];

t=-1;%-0.3033;%-0.2856 (-0.3033)
u=0.14;%0.02036 ;%0.03522 (0.02873)
phi=3*pi/4;%3*pi/4*exp(-pi^2/27);%phi=3*pi/4*exp(-pi^2/27);
M=0.2;

k=0;
kk=0;
n1=200;
n2=200;

j=0;

    for m=0:1:(n1-1)
    for n=0:1:(n2-1)

        k=k+1;
        R=a1*m+a2*n;
        K=b1*m/n1+b2*n/n2;
        Kv(k,1:2)=K;

        [d,dv,Dx,Dy]=dvk(t,u,M,phi,(m/n1)*2*pi,(n/n2)*2*pi);
            
        energy(k,1)=d;

        Gxx(k,1)=(Dx*Dx'-(dv*Dx')^2/d^2)/(4*d^2);
        Gyy(k,1)=(Dy*Dy'-(dv*Dy')^2/d^2)/(4*d^2);
        Gxy(k,1)=(Dx*Dy'-(dv*Dx')*(dv*Dy')/d^2)/(4*d^2);
        Fxy(k,1)=cross(Dx,Dy)*dv'/(2*d^3);
        Vd(k,1:2)=dv(1:2)/d;

        for sub=1:2
        
               kk=kk+1;
               
               if sub==1
               j=j+1;
               xy(kk,1:2)=R+da;
               end
               
               if sub==2
               xy(kk,1:2)=R-da;
               end
               
         end
               
    end
    end



% scatter(xy(1:2:end,1),xy(1:2:end,2),20,'blue','filled'); 
% hold on
% scatter(xy(2:2:end,1),xy(2:2:end,2),20,'red','filled'); 
% axis equal

volg=sqrt(Gxx.*Gyy-Gxy.*Gxy);

%draw_psi(energy,Kv,2);

volume=sum(volg)*(8*pi)/(n1*n2*3*sqrt(3));
spread=8*pi*sum(Gxx+Gyy)/(n1*n2*3*sqrt(3));
rxry=sum(Gxy)/(n1*n2*6*sqrt(3));
Chern=sum(Fxy)*(4*pi)/(n1*n2*3*sqrt(3));% volume>=|Chern|

draw_psi(Gxx+Gyy,Kv,2);
draw_psi(volg,Kv,2);
draw_psi(Fxy,Kv,1);

