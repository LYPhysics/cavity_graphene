close all
% % theta
% figure;
% plot(0:pi/100:pi/2,RvalleyK(1:end,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',35,'Fontname', 'Times New Roman');
% 
% legend('g/\omega_c=0.5','g/\omega_c=0.75','g/\omega_c=1');
% 


% figure;
% plot(0:0.01:2,gap(:,2)./Width(:,1),'LineWidth',2);
% xticks([0 0.926 2]);
% xline(0.926,'--');
% set(gca,'FontSize',35,'Fontname', 'Times New Roman');
% axes('Position',[.35 .5 .3 .3])
% box on
% plot(0:0.01:2,gap(:,2),'LineWidth',2);
% xticks([0  2]);
% xline(0.926,'--');
% set(gca,'FontSize',30,'Fontname', 'Times New Roman');



%EK-EK'
figure;
plot(0:0.01:2,abs(RvalleyK(1:end,1)),'LineWidth',2);
xticks([0 0.926 2]);
xline(0.926,'--');
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
axes('Position',[.58 .3 .3 .3])
box on
plot(0:0.01:2,-DE(1:end,1),'LineWidth',2);
%ylim([-0.2 1.3]);
yticks([0 ]);
xticks([0  2]);
xline(0.926,'--');
set(gca,'FontSize',25,'Fontname', 'Times New Roman');


figure;
plot(0:0.01:2,[photon1(1:end,1),photon2(1:end,1)],'LineWidth',2);
ylim([-0.08 0.08]);
xticks([0 0.926 2]);
xline(0.926,'--');
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
legend('K','K''','Position',[.2 .35 .1 .1])
axes('Position',[.584 .4 .3 .3])
box on
plot(0:0.01:2,gap(:,2)/wc,'LineWidth',2);
ylim([0 0.2]);
yticks([0 0.2]);
xticks([0 2]);
xline(0.926,'--');
set(gca,'FontSize',30,'Fontname', 'Times New Roman');



figure;
plot(0.01:0.01:2,[dT(2:end,1),dV(2:end,1)],'LineWidth',2);
ylim([-0.2 1.3]);
yticks([-0.1 0 0.5 1 1.1]);
xticks([0.01 0.926 2]);
xline(0.926,'--');
set(gca,'FontSize',35,'Fontname', 'Times New Roman');
legend('$\frac{T_K-T_{K''}}{E_K-E_{K''}}$','$\frac{V_K-V_{K''}}{E_K-E_{K''}}$','Interpreter','latex','Position',[.6 .5 .1 .1]);



% hold on
% plot(0:pi/100:pi/2,energyTheta(2,:),'LineWidth',2);
% legend('K','K''')
% 
% figure;
% plot(0:pi/100:pi/2,energyTheta(1,:)-energyTheta(2,:),'LineWidth',2);
% xticks([0 pi/8 pi/4 3*pi/8 pi/2]);
% xticklabels({'0','\pi/8','\pi/4','3\pi/8','\pi/2'});set(gca,'FontSize',25,'Fontname', 'Times New Roman');
% 
