function [d,dv,Dx,Dy]=dvk(t,u,Delta,phi,k1,k2)
d1=t*(1+cos(k1)+cos(k2));
d2=t*(sin(k1)-sin(k2));
d3=Delta-2*u*sin(phi)*(sin(k1)+sin(k2)-sin(k1+k2));

dv=[d1,d2,d3];

d=sqrt(d1^2+d2^2+d3^2);


Dv1=[-t*sin(k1),t*cos(k1),-2*u*sin(phi)*(cos(k1)-cos(k1+k2))];
Dv2=[-t*sin(k2),-t*cos(k2),-2*u*sin(phi)*(cos(k2)-cos(k1+k2))];

Dx=(Dv1-Dv2)*3/2;
Dy=(Dv1+Dv2)*sqrt(3)/2;

