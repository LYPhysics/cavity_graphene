function map = mycolormap(name,num)
%%% generate a colormap respect to color name, and color list length num
%%% if num is not provided, return the color list of length 30

if nargin < 1
    name = 'C1';
end

if nargin < 2
    num = 10;
end

longmap = colorcet(name);
coloraxis1 = linspace(0,1,num);
coloraxis2 = linspace(0,1,size(longmap,1));

color_r = interp1(coloraxis2,longmap(:,1),coloraxis1,'nearest');
color_g = interp1(coloraxis2,longmap(:,2),coloraxis1,'nearest');
color_b = interp1(coloraxis2,longmap(:,3),coloraxis1,'nearest');

map = [color_r; color_g; color_b];
map = map';
end